<?php

return [
    'status' => [
        'Pending'=>'Pending',
        'Accept'=>'Accept',
        'Delivery'=>'Delivery',
        'Success'=>'Success',
        'Cancle'=>'Cancle',
    ]
];
