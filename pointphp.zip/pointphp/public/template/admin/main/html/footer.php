<div id="footer">
		<p class="copyright">
			<a href="#">GNU General Public License</a>.	
		</p>
	</div>
</body>
</html>